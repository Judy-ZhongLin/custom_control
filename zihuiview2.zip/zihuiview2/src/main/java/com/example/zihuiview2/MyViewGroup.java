package com.example.zihuiview2;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class MyViewGroup extends ViewGroup {

    public MyViewGroup(Context context){
        super(context);
    }

    public MyViewGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    //获取子View宽度最大的值
    private int getMaxChildWidth(){
        int childCount = getChildCount();
        int maxWidth = 0;
        for(int i = 0; i<childCount; i++){
            View childView = getChildAt(i);
            if(childView.getMeasuredWidth()>maxWidth){
                maxWidth=childView.getMeasuredWidth();
            }
        }
        return maxWidth;
    }

    //获取总共的高度
    private int getTotalHeight(){
        int childCount = getChildCount();
        int height = 0;
        for(int i = 0; i<childCount; i++){
            View childView = getChildAt(i);
            height+=childView.getMeasuredHeight();
        }
        return height;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        //将所有的子View进行测量，该方法会出发每一个子View的onMeasure方法
        measureChildren(widthMeasureSpec,heightMeasureSpec);

        //得出宽高测量模式、大小
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);

        int childCount = getChildCount();

        //没有子View，当前ViewGroup没有存在意义，不占用空间
        if(childCount == 0){
            setMeasuredDimension(0,0);
        }else{
            //宽高都是包裹的情况
            if(widthMode == MeasureSpec.AT_MOST && heightMode == MeasureSpec.AT_MOST){
                int height = getTotalHeight();
                int width = getMaxChildWidth();
                //宽：min（子view的最大宽度，预定的ViewGroup宽度）
                setMeasuredDimension(Math.min(width,widthSize),Math.min(height, heightSize));
            }else if(heightMode == MeasureSpec.AT_MOST){//仅高度是包裹内容
                setMeasuredDimension(widthSize,getTotalHeight());
            }else if(widthMode == MeasureSpec.AT_MOST){
                setMeasuredDimension(getMaxChildWidth(),heightSize);
            }

        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        //t的初始值不为0.是因为传过来是相对于父容器的top

        int count = getChildCount();
        int curHeight = 0;
        for(int i = 0; i<count; i++){
            View child = getChildAt(i);
            int height = child.getMeasuredHeight();
            int width = child.getMeasuredWidth();
            child.layout(l,curHeight, width, curHeight+height);
            curHeight+=height;
        }
    }
}
