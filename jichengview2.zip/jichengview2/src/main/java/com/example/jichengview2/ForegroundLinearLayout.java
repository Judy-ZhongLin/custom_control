package com.example.jichengview2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class ForegroundLinearLayout extends LinearLayout {
    public ForegroundLinearLayout(Context context, AttributeSet attrs){
        super(context,attrs);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);

        canvas.drawColor(Color.parseColor("#50ff0000"));
    }
}
