package com.example.zihuiview1;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
    private int defalutSize;

    public MyView(Context context){
        super(context);
    }


    public MyView(Context context, AttributeSet attrs){
        super(context,attrs);
        //第二个参数就是styles.xml文件中<declare-styleable>标签的名字
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.MyView);

        //第一个参数为属性集合里面的属性，R文件名称：R.styleable+属性集合名称+下划线+属性的名称
        //第二个参数为，没有设置该属性时，默认设置的值
        defalutSize = a.getDimensionPixelSize(R.styleable.MyView_default_size, 100);
        //最后将TypedArray对象回收
        a.recycle();
    }

    private int getMySize(int defaltSize, int measureSpec){
        int mySize = defaltSize;
        int mode = MeasureSpec.getMode(measureSpec);
        int size = MeasureSpec.getSize(measureSpec);

        switch (mode) {
            //如果没有指定大小，就是默认大小
            case MeasureSpec.UNSPECIFIED:
                mySize = defaltSize;
                break;
            //如果测试模式最大值为size，我们将大小取为最大值，也可以取其他值，不大于父容器给予空间即可
            case MeasureSpec.AT_MOST:
                mySize = size;
                break;
            //固定大小则不改变
            case MeasureSpec.EXACTLY:
                mySize = size;
                break;
        }
        return mySize;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int width = getMySize(defalutSize, widthMeasureSpec);
        int height = getMySize(defalutSize, heightMeasureSpec);
        if(width<height){
            height = width;
        }else{
            width = height;
        }
        setMeasuredDimension(width,height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //调用父View的OnDraw函数，帮助实现基础绘制功能
        super.onDraw(canvas);
        //宽高相同
        int r = getMeasuredWidth()/2;

        Paint paint = new Paint();
        paint.setColor(Color.GREEN);
        //开始绘制的函数
        canvas.drawCircle(r,r,r,paint);

    }
}
