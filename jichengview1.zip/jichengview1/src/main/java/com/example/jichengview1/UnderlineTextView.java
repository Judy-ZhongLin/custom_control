package com.example.jichengview1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.TextView;
//告诉编译器忽略指定警告，不用在编译完成后出现警告信息
@SuppressWarnings("AppCompatCustomView")
public class UnderlineTextView extends TextView {
    public UnderlineTextView(Context context, AttributeSet attrs){
        super(context, attrs);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //绘制
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(5);
        int width = getWidth();
        int height = getBaseline();

        canvas.drawLine(0, height, width, height, paint);
    }
}
